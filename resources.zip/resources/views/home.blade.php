@extends('layouts.base')

@section('title', 'Мої оголошення')
@section('main')
    <p class="text-right"><a href="{{ route('bb.add') }}">Додати оголошення</a></p>
    @if (count($bbs) > 0)
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Товар</th>
                <th>Цiна, eur</th>
                <th colspan="2">&nbsp;</th>
            </tr>
        </thead>
        <tbody>
            @csrf
            @foreach($bbs as $bb)
            <tr>
                <td><h3>{{ $bb->title }}</h3></td>
                <td>{{ $bb->price }}</td>
                <td><a href=" {{ route('bb.edit', ['bb' => $bb->id]) }}">Змiнити</td>
                <td><a href="{{ route('bb.delete', ['bb' => $bb->id]) }}">Видалити</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @endif
@endsection('main')
