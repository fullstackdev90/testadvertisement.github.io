@extends('layouts.base')
@section('title', $bb->title)
@section('main')
                <h2>{{ $bb->title }}</h2>
                    <p>{{ $bb->content }}</p>
                    <p>{{ $bb->price }} eur. </p>
                    <p>Автор: {{ $bb->user->name}}</p>
                    <p><a href="{{ route('index') }}">Нa головну</a></p>
@endsection('main')