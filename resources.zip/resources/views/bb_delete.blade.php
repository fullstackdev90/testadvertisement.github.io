@extends('layouts.base')
@section('title', 'Видалити оголошення::Мої оголошення')

@section('main')        
        <form action="{{ route('bb.delete', ['bb' => $bb->id]) }}" method="POST">
            @csrf
                    
            <h2>{{ $bb->title }}</h2>
            <p>{{ $bb->content }}</p>
            <p>{{ $bb->price }} eur. </p>
            <p>Автор: {{ $bb->user->name}}</p>
            
            <input type="submit" class="btn btn-danger" vаluе="Видалити">
        </form>
@endsection('main')